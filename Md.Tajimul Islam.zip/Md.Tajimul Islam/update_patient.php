<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>modify patient</title>
  <link rel="stylesheet" href="css/css/add_patients.css" type="text/css">
</head>
<body>

<h3>MODIFY THE PATIENT</h3>

<div>
  <form action="add_patient.php" method="POST">
        <label for="patient name ">Patient Name </label>
        <input type="text" name="pname" placeholder="patient Name.." value=<?php echo $name; ?>>
        <label for="Gender">Gender</label>
        <select id="Gender" name="Gender" value=<?php echo $gnd; ?>>
          <option value=<?php echo $gnd; ?>><?php echo $gnd; ?></option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="others">Others</option>
        </select>
        <label for="age ">Age</label>
        <input type="text" name="age" placeholder="enter the age--" value=<?php echo $age; ?> >




        <label for="problem">Problem</label>
        <select id="problem" type="text" name="problem" value=<?php echo $prb; ?>>
          <option name="problem" value=<?php echo $prb; ?>><?php echo $prb; ?></option>
          <option name="problem"  value="Heart">Heart</option>
          <option name="problem"  value="Lunch">Lunch</option>
          <option name="problem"  value="Neuron">Neuron</option>
          <option name="problem"  value="Cancer">Cancer</option>
        </select>
        <label for="address ">Address</label><br>
        <textarea name="textarea" rows="5" cols="40" placeholder="enter full address----" value=<?php echo $addr; ?>><?php echo $addr; ?></textarea><br>
        <label for="contact ">Contact</label>
        <input type="text" name="contact" placeholder="enter contact number--" value=<?php echo $con; ?> >


        <input type="submit" name="submit" value="Update">
      </form>
</div>

</body>
</html>
