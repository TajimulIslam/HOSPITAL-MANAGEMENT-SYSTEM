<?php
require 'session.php';
 ?>
 <?php

$id = $_GET['id'];
$user = 'root';
$password = '';
$ip = 'localhost';
$dbname = 'hospital_management_system';
$connection_update = mysqli_connect($ip, $user, $password, $dbname);
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT *FROM patient WHERE `pid`='{$id}'";
  $result = mysqli_query($connection_update,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $name=$row['pname'];
    $gnd=$row['pgender'];
    $con=$row['pcontact'];
    $addr=$row['address'];
    $prb=$row['pproblem'];
    $age=$row['page'];

  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection_update);
require('update_patient.php');
//Update the data and Save it into the MySQL database;
if (isset($_POST['submit'])) {
  $user = 'root';
  $password = '';
  $ip = 'localhost';
  $dbname = 'hospital_management_system';

  $pname = $_POST['pname'];
  $gnd = $_POST['Gender'];
  $age = $_POST['age'];
  $problem = $_POST['problem'];
  $addr = $_POST['textarea'];
  $contact = $_POST['contact'];
  $connection_write = mysqli_connect($ip, $user, $password, $dbname);
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE patient SET `pname`='{$pname}',`pgender`='{$gnd}',
             `address`='{$addr}',`page`='{$age}',`pcontact`='{$contact}',`problem`='{$problem}' WHERE `pid`='{$id}' AND `visibility`=1 ";
    if(mysqli_query($connection_write, $query)){

      echo "<script>window.location.href = 'patients_list.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection_write);
}
?>
