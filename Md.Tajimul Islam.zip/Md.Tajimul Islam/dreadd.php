<?php
require 'session.php';
 ?>
 <?php

$user = 'root';
$password = '';
$ip = 'localhost';
$dbname = 'hospital_management_system';
$connection_delete = mysqli_connect($ip, $user, $password, $dbname);
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $visibility = 1;
  $update_query = "UPDATE doctor SET `visibility`= '{$visibility}' WHERE `did`='{$id}' ";
  if (mysqli_query($connection_delete,$update_query)) {
    echo "<script>window.location.href = 'doctors_list.php'</script>";
  }else{
    echo "ERROR : failed to Delete data"."<br>";
  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection_delete);
?>
