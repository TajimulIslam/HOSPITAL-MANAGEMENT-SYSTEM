<?php
require 'session.php';
 ?>
 <?php
$id = $_GET['id'];
$user = 'root';
$password = '';
$ip = 'localhost';
$dbname = 'hospital_management_system';
$connection_update = mysqli_connect($ip, $user, $password, $dbname);
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT *FROM gateman WHERE `id`='{$id}'";
  $result = mysqli_query($connection_update,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {

    $name1=$row['name'];
    $gnd=$row['gender'];
    $age=$row['age'];
    $con=$row['contact'];
    $post=$row['post'];
    $addr=$row['address'];



  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection_update);
require('update_stuff.html');
//Update the data and Save it into the MySQL database;
if (isset($_POST['submit'])) {
  $id = $_GET['id'];
  $user = 'root';
  $password = '';
  $ip = 'localhost';
  $dbname = 'hospital_management_system';

  $pname2 = $_POST['name'];
  $page2 = $_POST['age'];
  $pgender2 = $_POST['Gender'];
  $contact2 = $_POST['contact'];
  $addr2 = $_POST['textarea'];
  $specialist2 = $_POST['post'];

  $connection_write = mysqli_connect($ip, $user, $password, $dbname);
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE gateman SET `name`='{$pname2}',
             `gender`='{$pgender2}',`post`='{$specialist2}',`contact`='{$contact2}',
              `age`='{$page2}',`address`='{$addr2}' WHERE `id`='{$id}' ";
    if(mysqli_query($connection_write, $query)){
      echo "succefully updated";
      echo "<script>window.location.href = 'stuff_list.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection_write);
}
?>
