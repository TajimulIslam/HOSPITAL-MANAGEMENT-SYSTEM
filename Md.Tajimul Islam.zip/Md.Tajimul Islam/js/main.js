$(document).ready(function(){
    $("#power").click(function(){
        $("#power1").show();
    });
});

$(document).ready(function(){
    $("#main").click(function(){
    $(".submenu").slideToggle("slow");
    });
});


$(document).ready(function(){
    $("#main1").click(function(){
        $(".submenu1").slideToggle("slow");
    });
});
$(document).ready(function(){
    $("#main2").click(function(){
        $(".submenu2").slideToggle("slow");
    });
});
$(document).ready(function(){
    $("#main3").click(function(){
        $(".submenu3").slideToggle("slow");
    });
});
$(document).ready(function(){
    $("#main4").click(function(){
        $(".submenu4").slideToggle("slow");
    });
});
$(document).ready(function(){
    $("#main5").click(function(){
        $(".submenu5").slideToggle("slow");
    });
});



// tor clock
function starttime(){
  var today=new Date();
  var hours=today.getHours();
  if (hours>12) {
  hours=(hours-12);

  }
  var minutes=today.getMinutes();
  var seconds=today.getSeconds();
  if (seconds!=0) {
    t=seconds-seconds;
  }

  hours=tcheckime(hours);
  mmm=checkTime(minutes);
  mmn=checkime(seconds);
  var ann="AM";
  if (hours<12) {
    ann="PM";
    }

  document.getElementById('p1').innerHTML=hours+":"+mmm+":"+mmn+ann;
  setTimeout(starttime,100);

}
function checkTime(i){
  if(i<10){
    i="0"+i;
  }
  return i;

}
function checkime(i){
  if(i<10){
    i="0"+i;
  }
  return i;

}
function tcheckime(i){
  if(13<i){
    i=13+i;
  }
  return i;

}



// function DropdownMenu(menu,submenu){
//   $menu = document.getElementsByClassName("tabcontent");
//   $submenu = document.getElementsByIdName("tabcontent");
// $(document).ready(function(){
//     $("menu").click(function(){
//         $("submenu").slideToggle("slow");
//     });
//  });
// }
