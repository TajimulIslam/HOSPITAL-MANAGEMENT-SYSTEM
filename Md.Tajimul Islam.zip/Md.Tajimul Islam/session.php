<?php
session_start();
$ip ='localhost';
$username = 'root';
$password = '';
$dbname = 'hospital_management_system';
$user_check = $_SESSION['login_user'];
$connection = mysqli_connect($ip, $username, $password, $dbname);
$ses_sql = mysqli_query($connection,"SELECT `user_id` FROM admin WHERE `user_id` = '{$user_check}' ");
$row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
$login_session = $row['user_id'];
if(!isset($_SESSION['login_user'])){
  header("location:index0.php");
}
?>
