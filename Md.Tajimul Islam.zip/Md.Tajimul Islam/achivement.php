<?php
require 'session.php';
 ?>
 <!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>achivement</title>
    <link rel="stylesheet" href="css/achivement.css" media="screen" title="no title" charset="utf-8">
    <link rel="stylesheet" href="css/style.css" media="screen" title="no title" charset="utf-8">
    <link rel="stylesheet" href="css/font-awesome.css" media="screen" title="no title" charset="utf-8">
    <link rel="stylesheet" href="css/font-awesome.min.css" media="screen" title="no title" charset="utf-8">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="js/main.js"> </script>

  </head>
  <body onload="starttime();">

    <div class="banner">
        <div class="banner1">
          <div id="a1">
          </div>
          <div class="banner2">
            <img id="img1"src="img/log.jpg" alt="" />
          </div>
        </div>
        <div class="hudai">
          <h2 id="h2">DINAJPUR CLINIC HOME</h2>
          <h4>Balubari,Sadar,Dinajpur.</h4>
          <h3 id="h3">Email:bdclinicdinajpur@gmail.com</h3>
          <h3>contact:01706704905</h3>
        </div>
        <div class="right1">
          <img id="img2" src="img/download.png" alt="" />
          <!-- <img id="img3" src="images.png" alt="" /> -->
          <p id="p1">


          </p>
        </div>
      </div>


    <div class="body">
      <div class="h2">
        <h2>HOSPITAL MANAGMENT SYSTEM</h2>
      </div>
      <div class="hospital">
        <img src="img/6a.png" alt="" />
        <div class="hospital_right">
          <a id="power" href="logout_session.php"><i class="fa fa-power-off" style="font-size:36px;color:blue;"></i></a>

        </div>


      </div>
      <div class="menu">
        <h2>DINAJPUR CLINIC HOME</h2>
        <div class="admin">
          <img src="img/admin.jpg" alt="" />
          <p style="margin:0px;color:#f7f6f6;font-size: 13px;">TAJIMUL</h4>
          <h6><span><i id="radio" class="fa fa-circle text-success"></i></span>admin </p>

        </div>
<!--  this is menu part-->
<ul>
  <a href="index.php"><li><i class="fa fa-home"></i>Dashboard</li></a>
  <li><i class="fa fa-user-md"></i><span id="main">Doctor<i class="fa fa-angle-left pull-right" ></i></span>
    <ul class="submenu">
      <li><a href="add_doctor.php">Add Doctor</li></a>
      <li><a href="doctors_list.php">Doctor List</li></a>
    </ul>
  </li>
  <li> <span  id="main1"><i class="fa fa-wheelchair"></i>Patients<i class="fa fa-angle-left pull-right" ></i></span>
    <ul class="submenu1">
      <li><a href="add_patient.php">Add Patient</li></a>
      <li><a href="patients_list.php">Patients List</li></a>
    </ul>
  </li>
  <li><span  id="main2"><i class="fa fa-user-plus"></i>Appoint<i class="fa fa-angle-left pull-right" ></i></span>
    <ul class="submenu2">
      <li><a href="add_appointment.php">Add Appoint</li></a>
      <li><a href="appoints_list.php">Appoint List</li></a>
    </ul>
  </li >
  <li ><span id="main3"><i class="fa fa-handshake-o"></i>Others Stuff<i class="fa fa-angle-left pull-right" ></i></span>
    <ul class="submenu3">
      <li><a href="add_stuff.php">Add Stuffs</li></a>
      <li><a href="stuff_list.php">All  Stuffs</li></a>
    </ul>
  </li>
  <li ><span id="main4"><i class="fa fa-file-text"></i>Reports<i class="fa fa-angle-left pull-right" ></i></span>
    <ul class="submenu4">
      <li><a href="doctors_list.php">Doctors</li></a>
      <li><a href="patients_list.php">Patients</li></a>
      <li><a href="appoints_list.php">Appoints</li></a>
      <li><a href="stuff_list.php">Stuff</li></a>
    </ul>
  </li>
  <li ><span id="main5"><i class="fa fa-trash-o"></i>Deleted Reports<i class="fa fa-angle-left pull-right" ></i></span>
    <ul  class="submenu5">
      <li ><a href="ddoctor.php">Doctor Reports</li></a>
      <li><a href="dpatient.php">Patient Reports</li></a>
      <li><a href="dappoint.php">Appoint Reports</li></a>
      
    </ul>
  </li>
  <li><a href="index.php"><i class="fa fa-sign-language"></i>Achivements</a></li>
  </ul>
          <hr style="background:gray;">

      </div>
<!-- this is body part -->
      <div class="report">
        <h2>ALL MEMBER AND OWNER OF DINAJPUR CLINIC HOME</h2>
        <div class="owner">
          <a href="#" id="owner"><img src="img/owner1.jpg" style="width:200px;height:200px;"alt="" />
            <h4>  The Owner  </h4>
            <p> Suman Gangapadday </p>
            <p> M.Sc in CSE </p>
            <p> Contact:01521575985 </p>
          </a>
         </div>
         <div class="img1">
        <a href="#">
          <img src="img/doc5.jpg" alt="this is a image of this web" />
          <h3>Dr. Ayesha Begum</h3>
          <h3>Oncology specialist</h3>
          <h3>+880173771236</h3>
        </a>
      </div>
      <div class="img1">
        <a href="#">
          <img src="img/doc1.jpg" alt="this is a image of this web" />
          <h3>Dr. Simul Polas</h3>
          <h3>Heart specialist</h3>
          <h3>+8801706704905</h3>
        </a>
      </div>
      <div class="img1">
        <a href="#">
          <img src="img/doc2.jpg" alt="this is a image of this web" />
          <h3>Dr.Jhorna Rani</h3>
          <h3>Heart Gayni</h3>
          <h3>+880172828747</h3>
        </a>
      </div>
      <div class="img1">
        <a href="#">
          <img src="img/doc3.jpg" alt="this is a image of this web" />
          <h3>Dr. Silpa Shila</h3>
          <h3>Heart Child</h3>
          <h3>+8801938907454</h3>
        </a>
      </div>
      <div class="img1">
        <a href="#">
          <img src="img/doc4.jpg" alt="this is a image of this web" />
          <h3>Doctor Simul Polas</h3>
          <h3>Heart specialist</h3>
          <h3>+8801706704905</h3>
        </a>
      </div>
    </div>
  </div>

  </body>
</html>
