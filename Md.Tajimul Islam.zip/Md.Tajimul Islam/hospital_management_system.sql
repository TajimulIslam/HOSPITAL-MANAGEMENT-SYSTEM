-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 22, 2018 at 09:05 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `visibility` int(1) NOT NULL DEFAULT '1',
  `sl_no` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `password`, `visibility`, `sl_no`) VALUES
('admin', 'admin', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `appoint`
--

CREATE TABLE `appoint` (
  `dname` varchar(100) NOT NULL,
  `pname` varchar(200) NOT NULL,
  `visibility` int(1) NOT NULL,
  `appoint_time` varchar(100) NOT NULL,
  `appoint_date` varchar(100) NOT NULL,
  `ammount` varchar(101) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `aid` int(50) NOT NULL,
  `pgender` varchar(51) NOT NULL,
  `pproblem` varchar(20) NOT NULL,
  `dspeciality` varchar(20) NOT NULL,
  `ddegree` varchar(20) NOT NULL,
  `pcontact` varchar(11) NOT NULL,
  `page` varchar(5) NOT NULL,
  `address` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appoint`
--

INSERT INTO `appoint` (`dname`, `pname`, `visibility`, `appoint_time`, `appoint_date`, `ammount`, `time`, `aid`, `pgender`, `pproblem`, `dspeciality`, `ddegree`, `pcontact`, `page`, `address`) VALUES
('Taji', 'Tako', 1, '23:59', '2018-03-15', 'Male', '2018-03-21 15:06:42', 1, 'Male', 'Neuron', 'Heart', 'M.B.B.S', '01706704905', '', 'gfdsg'),
('Taji', 'Tako', 0, '23:59', '2018-03-15', 'Male', '2018-03-04 03:46:38', 2, 'Male', 'Neuron', 'Heart', 'M.B.B.S', '01706704905', '', 'gfdsg'),
('gfgf', 'Tako', 0, '13:00', '2018-03-20', 'Male', '2018-03-04 06:54:09', 3, 'Male', 'Heart', 'Lunch', 'MSE', '01706704905', '', 'FDDF'),
('Md.Waliullah Soni', 'Tako', 1, '12:58', '2018-03-13', 'others', '2018-03-21 15:06:47', 4, 'others', 'Heart', 'Heart', 'M.B.B.S', '01938907545', '', 'gh'),
('Taji', 'Tajimul', 1, '01:00', '2018-02-01', 'Male', '2018-03-21 15:06:56', 5, 'Male', 'Neuron', 'Lunch', 'MSE', '0123456789', '', 'Faridpur'),
('Taji', 'Tajimul', 0, '01:00', '2018-02-01', '2000', '2018-03-21 15:06:23', 6, 'Male', 'Neuron', 'Lunch', 'MSE', '0123456789', '', 'Faridpur'),
('Md.Waliullah Soni', 'Puran Ghos', 1, '02:00', '2018-03-04', '300', '2018-03-21 15:06:50', 7, '', '', '', '', '01521575985', '', 'ff'),
('Rumi Akther', 'Rann', 0, '12:59', '2018-03-28', '2000', '2018-03-04 16:04:44', 8, 'Male', 'Heart', 'Heart', 'M.B.B.S', '01827214536', '', 'Rongpur'),
('Arifuzzaman ', 'Ruma Akther', 0, '01:00', '2018-03-04', '7000', '2018-03-04 15:52:05', 9, 'Male', 'Lunch', 'Cancer', 'Cancer', '0172828474', '50', 'ff'),
('Arifuzzaman ', 'Ruma Akther', 0, '01:00', '2018-03-04', '7000', '2018-03-04 16:04:48', 10, 'Male', 'Lunch', 'Cancer', 'Cancer', '0172828474', '50', 'ff'),
('Md.Waliullah Soni', 'Tajimul', 0, '01:00', '2018-03-29', '1200', '2018-03-21 15:36:20', 11, '', '', '', '', '01706704905', '13', 'f'),
('Md.Waliullah Soni', 'Tajimul i', 0, '12:59', '2018-03-03', '141', '2018-03-22 07:09:12', 12, '', '', '', '', 'dffd', '13', 'sdfgs'),
('Md.Waliullah Soni', 'Tajimul', 1, '01:00', '2018-03-25', 'f', '2018-03-22 07:12:48', 13, 'Male', 'Cancer', 'Lunch', 'M.B.B.S', '01706704905', '20', 'f');

-- --------------------------------------------------------

--
-- Table structure for table `coocker`
--

CREATE TABLE `coocker` (
  `name` varchar(30) NOT NULL,
  `id` int(11) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `contact` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `dname` varchar(200) NOT NULL,
  `dspeciality` varchar(100) NOT NULL,
  `visibility` int(1) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dgender` varchar(20) NOT NULL,
  `ddegree` varchar(20) NOT NULL,
  `dcontact` varchar(11) NOT NULL,
  `did` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`dname`, `dspeciality`, `visibility`, `time`, `dgender`, `ddegree`, `dcontact`, `did`) VALUES
('Md.Waliullah Soni', 'Heart', 0, '2018-03-04 12:48:09', 'Male', 'MBBS', '01706704905', 2),
('Md.Waliullah Soni', 'Heart', 0, '2018-03-21 15:27:20', 'Male', 'MBBS', '01706704905', 3),
('Taji', 'Heart', 0, '2018-03-04 16:12:57', 'Male', 'Msc', '01706704905', 4),
('Arifuzzaman 0', 'Heart', 1, '2018-03-22 06:37:51', 'others', 'MSE', '01722520894', 5),
('NurAlam', 'Lunch', 1, '2018-03-22 07:08:50', 'Male', 'MBBS', '01794992256', 6),
('Rasel Ahmed', 'Lunch', 0, '2018-03-22 07:34:49', 'Female', 'M.B.B.S', '0172254621', 7),
('Al-Amin Islam', 'Heart', 0, '2018-03-22 07:23:29', 'Female', 'BCS', '01784032758', 8),
('Al-Amin Islam', 'Heart', 0, '2018-03-22 07:13:25', 'Female', 'BCS', '01784032758', 9),
('fdf', 'Cancer', 0, '2018-03-22 07:13:20', 'Male', 'f', '01706704905', 10);

-- --------------------------------------------------------

--
-- Table structure for table `gateman`
--

CREATE TABLE `gateman` (
  `name` varchar(30) NOT NULL,
  `id` int(1) NOT NULL,
  `post` varchar(30) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `age` varchar(10) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `education` varchar(30) NOT NULL,
  `address` varchar(100) NOT NULL,
  `visibility` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gateman`
--

INSERT INTO `gateman` (`name`, `id`, `post`, `contact`, `age`, `gender`, `education`, `address`, `visibility`) VALUES
('h', 1, '', '01706704905', '25', '', 'h', 'l', 0),
('dfgdg', 2, '', 'gfg', 'fgfd', '', 'fgfdg', 'gfdg', 0),
('Shojib Rahman', 3, '', '01722567894', '18', '', 'hsc', 'Panchagarh', 0),
('dfgdg', 4, '', '01521575985', '20', '', 'fgfdg', '11', 0),
('h', 5, '', '01938907545', '13', '', 'h', 'dsfa', 0),
('dfgdg', 6, 'Coocker', '01706704905', '13', 'others', 'h', 'f', 0),
('h', 7, 'Co-operator', '0152157598511', '20', 'others', 'h', ';', 0),
('hasib', 8, 'Nurse', '01706704905', '20', 'Male', 'hsc', 'ff', 0),
('Shojib Rahman', 9, 'Guard', 'fgfg', '13', 'Female', 'hsc', 'ff', 0);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `pname` varchar(200) NOT NULL,
  `address` varchar(100) NOT NULL,
  `pcontact` varchar(20) NOT NULL,
  `visibility` int(1) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `page` varchar(50) NOT NULL,
  `pproblem` varchar(51) NOT NULL,
  `pgender` varchar(51) NOT NULL,
  `pid` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`pname`, `address`, `pcontact`, `visibility`, `time`, `page`, `pproblem`, `pgender`, `pid`) VALUES
('<br /><b>Notice</b>:  Undefined variable: name in <b>C:xampphtdocsfinal_project2update_patient.html</b> on line <b>15</b><br />', '<br />\r\n<b>Notice</b>:  Undefined variable: addr in <b>C:xampphtdocsfinal_project2update_patient.htm', '<br /><b>Notice</b>:', 0, '2018-03-22 07:45:51', '<br /><b>Notice</b>:  Undefined variable: age in <', '<br />\r\n<b>Notice</b>:  Undefined variable: prb in ', '<br />\r\n<b>Notice</b>:  Undefined variable: gnd in ', 32),
('Tajimul', 'ff', 'ff', 1, '2018-03-22 07:44:58', '20', 'Neuron', 'Male', 33),
('Tajimul', 'ff', 'ff', 1, '2018-03-22 07:47:51', '20', 'Neuron', 'Male', 34);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `appoint`
--
ALTER TABLE `appoint`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `coocker`
--
ALTER TABLE `coocker`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `gateman`
--
ALTER TABLE `gateman`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`pid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appoint`
--
ALTER TABLE `appoint`
  MODIFY `aid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `coocker`
--
ALTER TABLE `coocker`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `did` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `gateman`
--
ALTER TABLE `gateman`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `pid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
