<?php
require 'session.php';
 ?>
 <?php
$id = $_GET['id'];
$user = 'root';
$password = '';
$ip = 'localhost';
$dbname = 'hospital_management_system';
$connection_update = mysqli_connect($ip, $user, $password, $dbname);
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT *FROM appoint WHERE `aid`='{$id}'";
  $result = mysqli_query($connection_update,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {
    $name=$row['pname'];
    $name1=$row['dname'];
    $gnd=$row['pgender'];
    $con=$row['pcontact'];
    $time=$row['appoint_time'];
    $date=$row['appoint_date'];
    $addr=$row['address'];
    $spec=$row['dspeciality'];
    $ddeg=$row['ddegree'];
    $prb=$row['pproblem'];
    $mny=$row['ammount'];
    $age=$row['page'];

  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection_update);
require('update_appoint.html');
//Update the data and Save it into the MySQL database;
if (isset($_POST['submit'])) {
  $id = $_GET['id'];
  $user = 'root';
  $password = '';
  $ip = 'localhost';
  $dbname = 'hospital_management_system';

  $pname2 = $_POST['pname'];
  $page2 = $_POST['page'];
  $pgender2 = $_POST['pgender'];
  $problem2 = $_POST['problem'];
  $textarea2 = $_POST['textarea'];
  $contact2 = $_POST['contact'];

  $degree2 = $_POST['degree'];
  $dname2 = $_POST['dname'];
  $specialist2 = $_POST['specialist'];
  $ammount2 = $_POST['ammount'];

  $date2 = $_POST['date'];
  $time2 = $_POST['time'];

  $connection_write = mysqli_connect($ip, $user, $password, $dbname);
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE appoint SET `pname`='{$pname2}',`dname`='{$dname2}',
             `pgender`='{$pgender2}',`ammount`='{$ammount2}',`pproblem`='{$problem2}',`dspeciality`='{$specialist2}',`pcontact`='{$contact2}',
              `address`='{$textarea2}',`page`='{$page2}',`ddegree`='{$degree2}',`appoint_date`='{$date2}',`appoint_time`='{$time2}' WHERE `aid`='{$id}' ";
    if(mysqli_query($connection_write, $query)){

      echo "<script>window.location.href = 'appoints_list.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection_write);
}
?>
