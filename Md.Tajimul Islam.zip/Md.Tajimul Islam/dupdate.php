<?php
require 'session.php';
 ?>
 <?php
$id = $_GET['id'];
$user = 'root';
$password = '';
$ip = 'localhost';
$dbname = 'hospital_management_system';
$connection_update = mysqli_connect($ip, $user, $password, $dbname);
$id = $_GET['id'];
if (!mysqli_connect_errno()){
  $query = "SELECT *FROM doctor WHERE `did`='{$id}'";
  $result = mysqli_query($connection_update,$query);
  if ($row = mysqli_fetch_array($result, MYSQLI_BOTH)) {

    $name1=$row['dname'];
    $gnd=$row['dgender'];
    $con=$row['dcontact'];
    $spec=$row['dspeciality'];
    $ddeg=$row['ddegree'];



  }
}else{
  echo "ERROR : Database connection failed !"."<br>";
}
mysqli_close($connection_update);
require('update_doctor.html');
//Update the data and Save it into the MySQL database;
if (isset($_POST['submit'])) {
  $id = $_GET['id'];
  $user = 'root';
  $password = '';
  $ip = 'localhost';
  $dbname = 'hospital_management_system';

  $pname2 = $_POST['dname'];

  $pgender2 = $_POST['dgender'];

  $contact2 = $_POST['dcontact'];

  $degree2 = $_POST['ddegree'];

  $specialist2 = $_POST['dspecialist'];

  $connection_write = mysqli_connect($ip, $user, $password, $dbname);
  if (!mysqli_connect_errno()) {
    $visibility = 1;
    $query = "UPDATE doctor SET `dname`='{$pname2}',
             `dgender`='{$pgender2}',`dspeciality`='{$specialist2}',`dcontact`='{$contact2}',
            `ddegree`='{$degree2}' WHERE `did`='{$id}' ";
    if(mysqli_query($connection_write, $query)){

      echo "<script>window.location.href = 'doctors_list.php'</script>";
    }else{
      echo "Database Insert Failed";
    }
  }else{
    die("ERROR : ".mysqli_connect_error());
  }
  mysqli_close($connection_write);
}
?>
