
<?php
require 'session.php';
 ?>
 <?php
if(isset($_POST['submit'])){
  $ip='localhost';
  $user='root';
  $dbname='hospital_management_system';
  $password='';

  $mail=$_POST['user'];
  $pass=$_POST['psd'];
  $connection=mysqli_connect($ip,$user,$password,$dbname);
  if (($mail="admin")&&($pass="admin")) {
  $query="INSERT INTO admin (`login_id`,`password`) VALUES('{$mail}','{$pass}')";
  mysqli_query($connection,$query);

  mysqli_close($connection);
}else {
  echo "inserted fail";
}
}
require 'index.html';

 ?>
